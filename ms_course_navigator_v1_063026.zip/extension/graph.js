const GRAPH = "https://graph.microsoft.com/v1.0";

async function saveState(token, state) {
  await fetch(`${GRAPH}/me/drive/special/approot:/state.json:/content`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(state)
  });
}

async function loadState(token) {
  const res = await fetch(`${GRAPH}/me/drive/special/approot:/state.json`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  return await res.json();
}