setTimeout(() => {
  chrome.storage.local.get("navState", (data) => {
    const last = data.navState?.lastVisited;

    if (last && location.href.includes("/courses/")) {
      

      // avoid infinite redirect loop
      if (location.href !== last) {
        window.location.href = last;
      }
    }
  });
}, 1200);

// ✅ Inject React bundle
(function injectReactApp() {
  const existing = document.getElementById("ms-learn-bookmode-script");
  if (existing) return;

  const script = document.createElement("script");
  script.id = "ms-learn-bookmode-script";

  const url = chrome.runtime.getURL("dist/index.js");
  

  script.src = url;

  script.onload = () => {
    
  };

  script.onerror = () => {
    console.error("❌ React bundle FAILED to load:", url);
  };

  document.documentElement.appendChild(script);

  
})();


// 🔁 Listen for requests FROM React
window.addEventListener("message", (event) => {
if (event.data?.type === "GET_NAV_STATE") {
  chrome.storage.local.get("navState", (data) => {
    window.postMessage({
      type: "NAV_STATE_RESPONSE",
      payload: data.navState || null
    });
  });
}
``
});

window.addEventListener("message", (event) => {
  if (event.data?.type === "GET_FULL_TOC") {
    chrome.storage.local.get(["fullTOC"], (data) => {
      

      window.postMessage({
        type: "FULL_TOC_RESPONSE",
        payload: data.fullTOC || []  // ✅ force fallback to []
      });
    });
  }
});

function sendPageVisit() {
  const payload = {
    title: document.querySelector("h1")?.innerText || document.title,
    url: location.href
  };

  

  try {
    chrome.runtime.sendMessage({
      type: "PAGE_VISIT",
      payload
    });

    
  } catch (err) {
    console.error("❌[ERROR] sendMessage crashed:", err);
  }
}
//COMBINED FIX (final working version)
function checkModuleCompletion() {
  // ✅ only run on real summary pages
  if (!window.location.pathname.match(/\/\d+-summary/)) return;

  const isComplete = document.querySelector(
    "span.is-shown-complete.has-text-success.docon.docon-check"
  );

  if (!isComplete) return;

  const url = window.location.href
    .replace(/\/\d+-summary.*$/, "")
    .replace(/\/+$/, "");

  

  chrome.runtime.sendMessage({
    type: "MODULE_COMPLETE",
    payload: { url }
  });
}
``


// Run immediately
sendPageVisit();

function triggerTOCBuild() {
  

  setTimeout(() => {
    buildFullTOC();
  }, 1200);
}

// Watch for SPA navigation
let lastUrl = location.href;

new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;

    

    sendPageVisit();
    setTimeout(checkModuleCompletion, 1000);


    if (location.href.includes("/courses/") || location.href.includes("/paths/")) {
      triggerTOCBuild();
    }
  }
}).observe(document.documentElement, {
  subtree: true,
  childList: true
});

window.addEventListener("message", (event) => {
  if (event.data?.type === "GET_TOC") {
    chrome.storage.local.get("courseTOC", (data) => {
      window.postMessage({
        type: "TOC_RESPONSE",
        payload: data.courseTOC
      });
    });
  }
});

window.addEventListener("message", (event) => {
  if (event.data?.type === "GET_NAV_STATE") {
    chrome.storage.local.get("navState", (data) => {
      

      window.postMessage({
        type: "NAV_STATE_RESPONSE",
        payload: data.navState || null
      });
    });
  }
});



async function fetchHTML(url) {
  const res = await fetch(url);
  const text = await res.text();

  const parser = new DOMParser();
  return parser.parseFromString(text, "text/html");
}
//Full final function(lock version)
function parseModulesFromDoc(doc) {
  const modules = [];
  const seen = new Set();

  const links = doc.querySelectorAll("a[href*='/modules/']");

  links.forEach(link => {
    const rawHref = link.getAttribute("href");
    if (!rawHref) return;

    // ✅ Remove Start sources
    if (link.closest("#module-actions")) return;
    const biName = link.getAttribute("data-bi-name");

    if (biName === "start" || biName === "continue") return;
    if (link.id && link.id.includes("start")) return;

    let url = new URL(rawHref, doc.baseURI).href;

    // ✅ ✅ ONLY fix missing /training/
    if (
      url.includes("/modules/") &&
      !url.includes("/training/modules/")
    ) {
      url = url.replace("/modules/", "/training/modules/");
    }

    url = url.replace(/\/+$/, "");

    // ✅ final filter
    if (!url.includes("/training/modules/")) return;
    const title = link.textContent?.replace(/\s+/g, " ").trim();
    if (!title) return;
    
    // ✅ Remove Continue entries
    if (title.toLowerCase() === "continue") return;

    const key = title.toLowerCase();

      if (
        title &&
        title.length > 5 &&
        !title.toLowerCase().includes("unit") &&
        !seen.has(key)
      ) {
        seen.add(key);
        modules.push({ title, url });
      }
  });
  
  

  return modules;
}

let isBuilding = false;

async function buildFullTOC() {
  if (isBuilding) {
    
    return;
  }

  isBuilding = true;
  

  const pathLinks = document.querySelectorAll("a[href*='/training/paths/']");
  const paths = [];

  for (const link of pathLinks) {
    const title = link.textContent?.trim();
    const url = link.href;

    if (!title) continue;

    

    try {
      let doc;

      // ✅ use live DOM if already on that path
      if (location.href.includes(url)) {
        
        doc = document;
      } else {
        doc = await fetchHTML(url);
      }

      let modules = parseModulesFromDoc(doc);

      // ✅ PATCH missing modules (safe)
      if (modules.length < 4) {
        

        const patchLinks = doc.querySelectorAll("a[data-linktype]");

        patchLinks.forEach(link => {
          const href = link.getAttribute("href");
          if (!href || !href.includes("modules")) return;

          let fixedUrl = new URL(href, doc.baseURI).href;

          if (
            fixedUrl.includes("/modules/") &&
            !fixedUrl.includes("/training/modules/")
          ) {
            fixedUrl = fixedUrl.replace("/modules/", "/training/modules/");
          }

          const title = link.textContent?.replace(/\s+/g, " ").trim();

          if (
            title &&
            title.length > 5 &&
            !modules.some(m => m.url === fixedUrl)
          ) {
            
            modules.push({ title, url: fixedUrl });
          }
        });
      }

      

      if (title.toLowerCase() !== "start") {
        paths.push({
          title,
          url,
          modules
        });
      }

    } catch (err) {
      console.error("❌ Failed:", url, "→ fallback");

      try {
        const fallbackModules = parseModulesFromDoc(document);

        if (fallbackModules.length) {
          paths.push({
            title,
            url,
            modules: fallbackModules
          });
        }
      } catch (fallbackErr) {
        console.error("🚫 Fallback failed:", url);
      }
    }
  }

  

  // ✅ Only update if valid
if (paths.length > 0) {
  chrome.storage.local.set({ fullTOC: paths }, () => {
    
    window.postMessage({ type: "TOC_READY" }, "*");
  });
}
chrome.storage.local.get("fullTOC", (data) => {
  
});

  // ✅ ALWAYS reset build lock
  isBuilding = false;
}
// ✅ ALWAYS build TOC on first load
if (location.href.includes("/courses/")) {
  

  setTimeout(() => {
    buildFullTOC();
  }, 1200);
}
